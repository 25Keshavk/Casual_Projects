


/*

Limit the starting and ending location entries (validate)


Make movement rules for the pieces

Rules for capturing pieces

Endgame condition

Rules for castling

*/